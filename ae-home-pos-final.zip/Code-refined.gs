// =============================================
// AE HOME POS SYSTEM — Google Apps Script
// Deploy: Execute as Me | Access: Anyone
// =============================================

// ─── SHEET NAMES ─────────────────────────────
const SHEETS = {
  products:    'Products',
  sales:       'Sales Transactions',
  cashiers:    'Cashiers',
  expenses:    'Expenses',
  allowances:  'Allowances',
  invLogs:     'Inventory Logs',
  receipts:    'Receipts Metadata',
  sessions:    'Active Sessions',
  voidLogs:    'Void Logs',
  salesExport: 'Sales Export',
};

// ─── SHEET HEADERS ───────────────────────────
const HEADERS = {
  products:   ['id','barcode','name','description','variants','category','qtyPcs','qtyPacks','pricePer','pricePack','createdAt'],
  sales:      ['id','transactionId','siNumber','cashierName','cashierId','date','items','total','cash','change','status','voidedBy','voidReason','voidDate'],
  cashiers:   ['id','name','username','password','role','active','createdAt'],
  expenses:   ['id','description','amount','date','addedBy'],
  allowances: ['id','forPerson','amount','date','addedBy'],
  invLogs:    ['id','date','productId','productName','type','qty','unit','adjustedBy','note'],
  receipts:   ['id','transactionId','siNumber','cashierName','date','total'],
  sessions:   ['userId','sessionId','username','name','role','loginTime','device'],
  voidLogs:    ['id','transactionId','voidedBy','voidReason','voidDate'],
  salesExport: ['id','transactionId','transactionDate','transactionTime','cashier','paymentMethod',
                'barcode','stockNo','productName','quantity','uomCode',
                'discount1','discount2','discount3','discount4','price','amount','remarks'],
};

// ─── CORS OUTPUT ─────────────────────────────
function makeOutput(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}

// ─── GET HANDLER ─────────────────────────────
function doGet(e) {
  try {
    // POST-via-GET (CORS workaround): base64-encoded JSON payload
    if (e.parameter.method === 'post' && e.parameter.data) {
      const bytes   = Utilities.base64Decode(e.parameter.data, Utilities.Charset.UTF_8);
      const decoded = decodeURIComponent(escape(bytes.map(b => String.fromCharCode(b & 0xff)).join('')));
      return makeOutput(handlePost(JSON.parse(decoded)));
    }

    const p      = e.parameter;
    const action = p.action;

    const GET_ACTIONS = {
      getProducts:        () => getProducts(),
      getSales:           () => getSales(),
      getCashiers:        () => getCashiers(),
      getExpenses:        () => getExpenses(),
      getAllowances:       () => getAllowances(),
      getInventoryLogs:   () => getInventoryLogs(),
      getReceiptsMetadata:() => getReceiptsMetadata(),
      getSalesExport:     () => getSalesExport(e.parameter),
      login:              () => loginUser(p.username, p.password),
      bulkAddProducts:    () => bulkAddProductsFromParams(p),
      checkSession:       () => checkSession(p.userId, p.sessionId),
    };

    const handler = GET_ACTIONS[action];
    if (!handler) return makeOutput({ success: false, message: 'Unknown action: ' + action });
    return makeOutput(handler());
  } catch (err) {
    return makeOutput({ success: false, message: err.toString() });
  }
}

// ─── POST HANDLER ────────────────────────────
function doPost(e) {
  try {
    return makeOutput(handlePost(JSON.parse(e.postData.contents)));
  } catch (err) {
    return makeOutput({ success: false, message: err.toString() });
  }
}

function handlePost(payload) {
  const action = payload.action;

  const POST_ACTIONS = {
    addProduct:        () => addProduct(payload),
    updateProduct:     () => updateProduct(payload),
    deleteProduct:     () => deleteProduct(payload.id),
    bulkAddProducts:   () => bulkAddProducts(payload),
    stockAdjust:       () => stockAdjust(payload),
    saveSale:          () => saveSale(payload),
    addCashier:        () => addCashier(payload),
    updateCashier:     () => updateCashier(payload),
    deleteCashier:     () => deleteCashier(payload.id),
    addExpense:        () => addExpense(payload),
    deleteExpense:     () => deleteRecord(SHEETS.expenses, payload.id),
    addAllowance:      () => addAllowance(payload),
    deleteAllowance:   () => deleteRecord(SHEETS.allowances, payload.id),
    voidTransaction:   () => voidTransaction(payload),
    saveSalesExport:   () => saveSalesExportRows(payload),
    registerSession:   () => registerSession(payload),
    unregisterSession: () => unregisterSession(payload.userId, payload.sessionId),
  };

  const handler = POST_ACTIONS[action];
  if (!handler) return { success: false, message: 'Unknown action: ' + action };
  return handler();
}

// ─── SHEET HELPERS ───────────────────────────
function getSheet(name) {
  const ss    = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(name) || ss.insertSheet(name);
  return sheet;
}

/**
 * Convert a sheet's rows into an array of objects keyed by header names.
 * Rows with no 'id' value are skipped (header-only or blank rows).
 */
function sheetToObjects(sheetName) {
  const sheet = getSheet(sheetName);
  const data  = sheet.getDataRange().getValues();
  if (data.length < 2) return [];
  const headers = data[0].map(String);
  return data.slice(1)
    .map(row => {
      const obj = {};
      headers.forEach((h, i) => {
        const v = row[i];
        if (v === null || v === undefined || v === '') {
          obj[h] = '';
        } else if (v instanceof Date) {
          // Always return ISO string so frontend parseDate() works reliably
          obj[h] = Utilities.formatDate(v, Session.getScriptTimeZone(), "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        } else {
          obj[h] = String(v);
        }
      });
      return obj;
    })
    .filter(obj => obj.id && obj.id.trim() !== '');
}

function generateId() {
  return Utilities.getUuid().replace(/-/g, '').substring(0, 16);
}

/**
 * Returns the 1-based row number of the row whose 'id' column matches the given id.
 * Returns -1 if not found.
 */
function findRowById(sheet, id) {
  const data    = sheet.getDataRange().getValues();
  const headers = data[0].map(String);
  const idCol   = headers.indexOf('id');
  if (idCol === -1) return -1;
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][idCol]).trim() === String(id).trim()) return i + 1;
  }
  return -1;
}

/**
 * Ensures the first row of a sheet contains the given headers.
 * Only writes headers if the sheet is empty or the first row is blank.
 * Never overwrites existing data.
 */
function ensureHeaders(sheetName, headers) {
  const sheet   = getSheet(sheetName);
  const lastRow = sheet.getLastRow();
  if (lastRow === 0) {
    sheet.getRange(1, 1, 1, headers.length)
      .setValues([headers])
      .setFontWeight('bold')
      .setBackground('#d9ead3');
    return;
  }
  const firstRow = sheet.getRange(1, 1, 1, Math.max(sheet.getLastColumn(), headers.length)).getValues()[0];
  const isEmpty  = firstRow.every(v => v === '' || v === null || v === undefined);
  if (isEmpty) {
    sheet.getRange(1, 1, 1, headers.length)
      .setValues([headers])
      .setFontWeight('bold')
      .setBackground('#d9ead3');
  }
}

/**
 * Returns the column index (0-based) of a header, or -1.
 */
function getColIndex(headers, colName) {
  return headers.map(String).indexOf(colName);
}

// ─── PRODUCTS ────────────────────────────────
function getProducts() {
  ensureHeaders(SHEETS.products, HEADERS.products);
  return { success: true, data: sheetToObjects(SHEETS.products) };
}

function addProduct(p) {
  ensureHeaders(SHEETS.products, HEADERS.products);
  const sheet = getSheet(SHEETS.products);
  const id    = generateId();
  const row   = [
    id,
    String(p.barcode || ''),
    String(p.name    || '').trim(),
    String(p.description || ''),
    String(p.variants    || ''),
    String(p.category    || ''),
    parseInt(p.qtyPcs    || 0) || 0,
    parseInt(p.qtyPacks  || 0) || 0,
    parseFloat(p.pricePer  || 0) || 0,
    parseFloat(p.pricePack || 0) || 0,
    new Date().toISOString(),
  ];
  sheet.appendRow(row);

  // Force barcode cell to text to preserve leading zeros
  const lastRow    = sheet.getLastRow();
  const barcodeCol = HEADERS.products.indexOf('barcode') + 1;
  sheet.getRange(lastRow, barcodeCol)
    .setNumberFormat('@')
    .setValue(String(p.barcode || ''));

  if (parseInt(p.qtyPcs || 0) > 0) {
    logInventory({ productId: id, productName: p.name, type: 'in', qty: parseInt(p.qtyPcs), unit: 'pcs', note: 'Initial stock', adjustedBy: 'System' });
  }
  return { success: true, id };
}

function updateProduct(p) {
  const sheet = getSheet(SHEETS.products);
  const row   = findRowById(sheet, p.id);
  if (row === -1) return { success: false, message: 'Product not found.' };

  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);

  const updates = {
    name:        String(p.name || '').trim(),
    description: String(p.description || ''),
    variants:    String(p.variants    || ''),
    category:    String(p.category    || ''),
    qtyPcs:      parseInt(p.qtyPcs    || 0) || 0,
    qtyPacks:    parseInt(p.qtyPacks  || 0) || 0,
    pricePer:    parseFloat(p.pricePer  || 0) || 0,
    pricePack:   parseFloat(p.pricePack || 0) || 0,
  };

  Object.entries(updates).forEach(([col, val]) => {
    const idx = getColIndex(headers, col);
    if (idx >= 0) sheet.getRange(row, idx + 1).setValue(val);
  });

  // Force barcode as text
  const barcodeIdx = getColIndex(headers, 'barcode');
  if (barcodeIdx >= 0) {
    sheet.getRange(row, barcodeIdx + 1)
      .setNumberFormat('@')
      .setValue(String(p.barcode || ''));
  }

  return { success: true };
}

function deleteProduct(id) {
  const sheet = getSheet(SHEETS.products);
  const row   = findRowById(sheet, id);
  if (row === -1) return { success: false, message: 'Product not found.' };
  sheet.deleteRow(row);
  return { success: true };
}

// ─── BULK IMPORT (POST body) ─────────────────
function bulkAddProducts(payload) {
  ensureHeaders(SHEETS.products, HEADERS.products);
  const sheet = getSheet(SHEETS.products);

  let rows = [];
  try { rows = JSON.parse(payload.products || '[]'); } catch(e) { return { success: false, message: 'Invalid products JSON.' }; }

  const validRows = rows.filter(p => p && String(p.name || '').trim());
  if (!validRows.length) return { success: true, count: 0 };

  const now  = new Date().toISOString();
  const data = validRows.map(p => [
    generateId(),
    String(p.barcode || ''),
    String(p.name).trim(),
    String(p.description || ''),
    String(p.variants    || ''),
    String(p.category    || ''),
    parseInt(p.qtypcs   || p.qtyPcs   || p['qty(pcs)']   || 0) || 0,
    parseInt(p.qtypacks || p.qtyPacks || p['qty(packs)'] || 0) || 0,
    parseFloat(p.priceper  || p.pricePer  || p['price/pc']  || 0) || 0,
    parseFloat(p.pricepack || p.pricePack || p['price/pack'] || 0) || 0,
    now,
  ]);

  const startRow = Math.max(sheet.getLastRow(), 1) + 1;
  sheet.getRange(startRow, 1, data.length, data[0].length).setValues(data);

  // Format barcode column as text
  const barcodeCol = HEADERS.products.indexOf('barcode') + 1;
  sheet.getRange(startRow, barcodeCol, data.length, 1).setNumberFormat('@');

  return { success: true, count: data.length };
}

// ─── BULK IMPORT (GET params) ─────────────────
function bulkAddProductsFromParams(params) {
  ensureHeaders(SHEETS.products, HEADERS.products);
  const sheet = getSheet(SHEETS.products);
  const count = parseInt(params.count || 0);
  if (!count) return { success: false, message: 'No products in request.' };

  const now  = new Date().toISOString();
  const data = [];
  for (let i = 0; i < count; i++) {
    const name = String(params['p' + i + '_name'] || '').trim();
    if (!name) continue;
    data.push([
      generateId(),
      String(params['p' + i + '_barcode']   || ''),
      name,
      '',
      '',
      '',
      parseInt(params['p' + i + '_qtyPcs']   || 0) || 0,
      parseInt(params['p' + i + '_qtyPacks'] || 0) || 0,
      parseFloat(params['p' + i + '_pricePer']  || 0) || 0,
      parseFloat(params['p' + i + '_pricePack'] || 0) || 0,
      now,
    ]);
  }

  if (!data.length) return { success: true, count: 0 };

  const startRow   = Math.max(sheet.getLastRow(), 1) + 1;
  sheet.getRange(startRow, 1, data.length, data[0].length).setValues(data);

  const barcodeCol = HEADERS.products.indexOf('barcode') + 1;
  sheet.getRange(startRow, barcodeCol, data.length, 1).setNumberFormat('@');

  return { success: true, count: data.length };
}

// ─── STOCK ADJUST ────────────────────────────
function stockAdjust(payload) {
  const sheet   = getSheet(SHEETS.products);
  const row     = findRowById(sheet, payload.id);
  if (row === -1) return { success: false, message: 'Product not found.' };

  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
  const qtyCol  = payload.unit === 'packs' ? 'qtyPacks' : 'qtyPcs';
  const idx     = getColIndex(headers, qtyCol);
  if (idx < 0) return { success: false, message: 'Quantity column not found.' };

  const current = parseInt(sheet.getRange(row, idx + 1).getValue() || 0) || 0;
  const qty     = parseInt(payload.qty || 0) || 0;
  const newQty  = payload.direction === 'in' ? current + qty : Math.max(0, current - qty);
  sheet.getRange(row, idx + 1).setValue(newQty);

  const nameIdx     = getColIndex(headers, 'name');
  const productName = nameIdx >= 0 ? String(sheet.getRange(row, nameIdx + 1).getValue()) : payload.id;

  logInventory({
    productId:   payload.id,
    productName,
    type:        payload.direction,
    qty,
    unit:        payload.unit || 'pcs',
    note:        payload.note || '',
    adjustedBy:  payload.adjustedBy || 'System',
    date:        payload.date || new Date().toISOString(),
  });

  return { success: true };
}

// ─── INVENTORY LOG ───────────────────────────
function logInventory(data) {
  ensureHeaders(SHEETS.invLogs, HEADERS.invLogs);
  const sheet = getSheet(SHEETS.invLogs);
  sheet.appendRow([
    generateId(),
    data.date        || new Date().toISOString(),
    data.productId   || '',
    data.productName || '',
    data.type        || '',
    data.qty         || 0,
    data.unit        || 'pcs',
    data.adjustedBy  || '',
    data.note        || '',
  ]);
}

function getInventoryLogs() {
  ensureHeaders(SHEETS.invLogs, HEADERS.invLogs);
  return { success: true, data: sheetToObjects(SHEETS.invLogs) };
}

// ─── SALES ───────────────────────────────────
function getSales() {
  ensureHeaders(SHEETS.sales, HEADERS.sales);
  return { success: true, data: sheetToObjects(SHEETS.sales) };
}

function saveSale(payload) {
  ensureHeaders(SHEETS.sales, HEADERS.sales);
  const sheet = getSheet(SHEETS.sales);
  const id    = generateId();

  const saleDate = payload.date || new Date().toISOString();
  sheet.appendRow([
    id,
    payload.transactionId || '',
    payload.siNumber      || '',
    payload.cashierName   || '',
    payload.cashierId     || '',
    saleDate,
    payload.items         || '[]',
    parseFloat(payload.total  || 0) || 0,
    parseFloat(payload.cash   || 0) || 0,
    parseFloat(payload.change || 0) || 0,
    'ACTIVE',
    '', '', '',
  ]);

  // Force date column to plain text so Sheets doesn't auto-convert to a Date type
  const saleDateCol = HEADERS.sales.indexOf('date') + 1;
  const saleLastRow = sheet.getLastRow();
  if (saleDateCol > 0) {
    sheet.getRange(saleLastRow, saleDateCol).setNumberFormat('@').setValue(saleDate);
  }

  // Deduct stock for each sold item
  try {
    const items      = JSON.parse(payload.items || '[]');
    const prodSheet  = getSheet(SHEETS.products);
    const prodData   = prodSheet.getDataRange().getValues();
    const prodHdr    = prodData[0].map(String);
    const idIdx      = getColIndex(prodHdr, 'id');
    const nameIdx    = getColIndex(prodHdr, 'name');
    const pcsIdx     = getColIndex(prodHdr, 'qtyPcs');
    const pkIdx      = getColIndex(prodHdr, 'qtyPacks');

    // Build lookup map: productId → row index (1-based)
    const rowMap = {};
    for (let i = 1; i < prodData.length; i++) {
      rowMap[String(prodData[i][idIdx])] = i;
    }

    items.forEach(item => {
      const i = rowMap[String(item.productId)];
      if (i === undefined) return;

      if (item.unit === 'pack' && pkIdx >= 0) {
        const cur = parseInt(prodData[i][pkIdx] || 0) || 0;
        prodSheet.getRange(i + 1, pkIdx + 1).setValue(Math.max(0, cur - item.qty));
      } else if (pcsIdx >= 0) {
        const cur = parseInt(prodData[i][pcsIdx] || 0) || 0;
        prodSheet.getRange(i + 1, pcsIdx + 1).setValue(Math.max(0, cur - item.qty));
      }

      const pName = nameIdx >= 0 ? String(prodData[i][nameIdx]) : (item.name || item.productId);
      logInventory({
        productId:   item.productId,
        productName: pName,
        type:        'sale',
        qty:         item.qty,
        unit:        item.unit || 'pcs',
        adjustedBy:  payload.cashierName || '',
        note:        'Sale: ' + (payload.transactionId || ''),
        date:        payload.date || new Date().toISOString(),
      });
    });
  } catch(e) {
    // Stock deduction failed — log but don't fail the sale
    Logger.log('saveSale stock deduction error: ' + e.toString());
  }

  // Mirror to Receipts Metadata sheet
  ensureHeaders(SHEETS.receipts, HEADERS.receipts);
  getSheet(SHEETS.receipts).appendRow([
    generateId(),
    payload.transactionId || '',
    payload.siNumber      || '',
    payload.cashierName   || '',
    payload.date          || new Date().toISOString(),
    parseFloat(payload.total || 0) || 0,
  ]);

  return { success: true, id };
}

// ─── CASHIERS ────────────────────────────────
function getCashiers() {
  ensureHeaders(SHEETS.cashiers, HEADERS.cashiers);
  // Never return passwords to the frontend
  const data = sheetToObjects(SHEETS.cashiers).map(c => {
    const safe = Object.assign({}, c);
    delete safe.password;
    return safe;
  });
  return { success: true, data };
}

function addCashier(p) {
  ensureHeaders(SHEETS.cashiers, HEADERS.cashiers);
  const sheet    = getSheet(SHEETS.cashiers);
  const existing = sheetToObjects(SHEETS.cashiers);

  if (existing.find(c => c.username === (p.username || '').trim())) {
    return { success: false, message: 'Username already exists.' };
  }

  const id = generateId();
  sheet.appendRow([
    id,
    String(p.name     || '').trim(),
    String(p.username || '').trim(),
    Utilities.base64Encode(p.password || ''),
    p.role   || 'cashier',
    'true',
    new Date().toISOString(),
  ]);
  return { success: true, id };
}

function updateCashier(p) {
  const sheet = getSheet(SHEETS.cashiers);
  const row   = findRowById(sheet, p.id);
  if (row === -1) return { success: false, message: 'User not found.' };

  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
  const updates = {
    name:     String(p.name     || '').trim(),
    username: String(p.username || '').trim(),
    role:     p.role || 'cashier',
  };
  Object.entries(updates).forEach(([col, val]) => {
    const idx = getColIndex(headers, col);
    if (idx >= 0) sheet.getRange(row, idx + 1).setValue(val);
  });
  if (p.password) {
    const pwIdx = getColIndex(headers, 'password');
    if (pwIdx >= 0) sheet.getRange(row, pwIdx + 1).setValue(Utilities.base64Encode(p.password));
  }
  return { success: true };
}

function deleteCashier(id) {
  const sheet = getSheet(SHEETS.cashiers);
  const row   = findRowById(sheet, id);
  if (row === -1) return { success: false, message: 'User not found.' };
  sheet.deleteRow(row);
  return { success: true };
}

function loginUser(username, password) {
  if (!username || !password) return { success: false, message: 'Username and password required.' };

  ensureHeaders(SHEETS.cashiers, HEADERS.cashiers);
  const sheet   = getSheet(SHEETS.cashiers);
  const data    = sheet.getDataRange().getValues();
  const headers = data[0].map(String);

  const unIdx   = getColIndex(headers, 'username');
  const pwIdx   = getColIndex(headers, 'password');
  const nameIdx = getColIndex(headers, 'name');
  const roleIdx = getColIndex(headers, 'role');
  const idIdx   = getColIndex(headers, 'id');
  const actIdx  = getColIndex(headers, 'active');

  const encoded = Utilities.base64Encode(password);

  for (let i = 1; i < data.length; i++) {
    const rowUn  = String(data[i][unIdx]  || '').trim();
    const rowAct = String(data[i][actIdx] || 'true').trim();
    if (rowUn !== username.trim()) continue;
    if (rowAct === 'false') return { success: false, message: 'Account is inactive.' };
    if (String(data[i][pwIdx]) !== encoded) return { success: false, message: 'Incorrect password.' };
    return {
      success: true,
      id:   String(data[i][idIdx]   || ''),
      name: String(data[i][nameIdx] || ''),
      role: String(data[i][roleIdx] || 'cashier'),
    };
  }
  return { success: false, message: 'User not found.' };
}

// ─── EXPENSES ────────────────────────────────
function getExpenses() {
  ensureHeaders(SHEETS.expenses, HEADERS.expenses);
  return { success: true, data: sheetToObjects(SHEETS.expenses) };
}

function addExpense(p) {
  ensureHeaders(SHEETS.expenses, HEADERS.expenses);
  getSheet(SHEETS.expenses).appendRow([
    generateId(),
    String(p.description || '').trim(),
    parseFloat(p.amount  || 0) || 0,
    p.date     || new Date().toISOString(),
    p.addedBy  || '',
  ]);
  return { success: true };
}

// ─── ALLOWANCES ──────────────────────────────
function getAllowances() {
  ensureHeaders(SHEETS.allowances, HEADERS.allowances);
  return { success: true, data: sheetToObjects(SHEETS.allowances) };
}

function addAllowance(p) {
  ensureHeaders(SHEETS.allowances, HEADERS.allowances);
  getSheet(SHEETS.allowances).appendRow([
    generateId(),
    String(p.forPerson || '').trim(),
    parseFloat(p.amount || 0) || 0,
    p.date    || new Date().toISOString(),
    p.addedBy || '',
  ]);
  return { success: true };
}

// ─── RECEIPTS METADATA ───────────────────────
function getReceiptsMetadata() {
  ensureHeaders(SHEETS.receipts, HEADERS.receipts);
  return { success: true, data: sheetToObjects(SHEETS.receipts) };
}

// ─── GENERIC DELETE ──────────────────────────
function deleteRecord(sheetName, id) {
  if (!id) return { success: false, message: 'No ID provided.' };
  const sheet = getSheet(sheetName);
  const row   = findRowById(sheet, id);
  if (row === -1) return { success: false, message: 'Record not found.' };
  sheet.deleteRow(row);
  return { success: true };
}

// ─── VOID TRANSACTION ────────────────────────
function voidTransaction(payload) {
  try {
    const sheet   = getSheet(SHEETS.sales);
    const data    = sheet.getDataRange().getValues();
    const headers = data[0].map(String);

    const txIdx        = getColIndex(headers, 'transactionId');
    const statusIdx    = getColIndex(headers, 'status');
    const voidedByIdx  = getColIndex(headers, 'voidedBy');
    const voidReasonIdx= getColIndex(headers, 'voidReason');
    const voidDateIdx  = getColIndex(headers, 'voidDate');
    const itemsIdx     = getColIndex(headers, 'items');

    // Find the transaction
    let txRow  = -1;
    let txData = null;
    for (let i = 1; i < data.length; i++) {
      if (String(data[i][txIdx]).trim() === String(payload.transactionId).trim()) {
        txRow  = i + 1;
        txData = data[i];
        break;
      }
    }
    if (txRow === -1) return { success: false, message: 'Transaction not found.' };

    // Check already voided
    if (statusIdx >= 0 && String(txData[statusIdx]).trim() === 'VOID') {
      return { success: false, message: 'Transaction is already voided.' };
    }

    const voidDate = payload.voidDate || new Date().toISOString();

    // Update status columns — add them if they don't exist yet (legacy sheets)
    if (statusIdx === -1) {
      const lastCol = headers.length + 1;
      sheet.getRange(1, lastCol).setValue('status');
      sheet.getRange(1, lastCol + 1).setValue('voidedBy');
      sheet.getRange(1, lastCol + 2).setValue('voidReason');
      sheet.getRange(1, lastCol + 3).setValue('voidDate');
      sheet.getRange(txRow, lastCol).setValue('VOID');
      sheet.getRange(txRow, lastCol + 1).setValue(payload.voidedBy  || '');
      sheet.getRange(txRow, lastCol + 2).setValue(payload.voidReason || '');
      sheet.getRange(txRow, lastCol + 3).setValue(voidDate);
    } else {
      sheet.getRange(txRow, statusIdx     + 1).setValue('VOID');
      if (voidedByIdx   >= 0) sheet.getRange(txRow, voidedByIdx   + 1).setValue(payload.voidedBy   || '');
      if (voidReasonIdx >= 0) sheet.getRange(txRow, voidReasonIdx + 1).setValue(payload.voidReason  || '');
      if (voidDateIdx   >= 0) sheet.getRange(txRow, voidDateIdx   + 1).setValue(voidDate);
    }

    // Restore stock for each item in the voided transaction
    try {
      const items      = JSON.parse(String(txData[itemsIdx] || '[]'));
      const prodSheet  = getSheet(SHEETS.products);
      const prodData   = prodSheet.getDataRange().getValues();
      const prodHdr    = prodData[0].map(String);
      const idIdx      = getColIndex(prodHdr, 'id');
      const nameIdx    = getColIndex(prodHdr, 'name');
      const pcsIdx     = getColIndex(prodHdr, 'qtyPcs');
      const pkIdx      = getColIndex(prodHdr, 'qtyPacks');

      // Build lookup map for speed
      const rowMap = {};
      for (let i = 1; i < prodData.length; i++) {
        rowMap[String(prodData[i][idIdx])] = i;
      }

      items.forEach(item => {
        const i = rowMap[String(item.productId)];
        if (i === undefined) return;

        if (item.unit === 'pack' && pkIdx >= 0) {
          const cur = parseInt(prodData[i][pkIdx] || 0) || 0;
          prodSheet.getRange(i + 1, pkIdx + 1).setValue(cur + item.qty);
        } else if (pcsIdx >= 0) {
          const cur = parseInt(prodData[i][pcsIdx] || 0) || 0;
          prodSheet.getRange(i + 1, pcsIdx + 1).setValue(cur + item.qty);
        }

        const pName = nameIdx >= 0 ? String(prodData[i][nameIdx]) : (item.name || item.productId);
        logInventory({
          productId:   item.productId,
          productName: pName,
          type:        'in',
          qty:         item.qty,
          unit:        item.unit || 'pcs',
          adjustedBy:  payload.voidedBy || 'System',
          note:        'VOID: ' + payload.transactionId + ' — ' + (payload.voidReason || ''),
          date:        voidDate,
        });
      });
    } catch(e) {
      Logger.log('voidTransaction stock restore error: ' + e.toString());
    }

    // Log void to Void Logs sheet
    ensureHeaders(SHEETS.voidLogs, HEADERS.voidLogs);
    getSheet(SHEETS.voidLogs).appendRow([
      generateId(),
      payload.transactionId || '',
      payload.voidedBy      || '',
      payload.voidReason    || '',
      voidDate,
    ]);

    return { success: true };
  } catch(e) {
    return { success: false, message: e.toString() };
  }
}

// ─── SESSION MANAGEMENT ──────────────────────
function registerSession(payload) {
  ensureHeaders(SHEETS.sessions, HEADERS.sessions);
  const sheet   = getSheet(SHEETS.sessions);
  const data    = sheet.getDataRange().getValues();
  const headers = (data[0] || []).map(String);
  const userIdx = getColIndex(headers, 'userId');

  // Remove all existing sessions for this user (enforce single active session)
  for (let i = data.length - 1; i >= 1; i--) {
    if (String(data[i][userIdx]).trim() === String(payload.userId).trim()) {
      sheet.deleteRow(i + 1);
    }
  }

  sheet.appendRow([
    payload.userId    || '',
    payload.sessionId || '',
    payload.username  || '',
    payload.name      || '',
    payload.role      || '',
    new Date().toISOString(),
    payload.device    || '',
  ]);
  return { success: true };
}

function unregisterSession(userId, sessionId) {
  try {
    const sheet   = getSheet(SHEETS.sessions);
    const data    = sheet.getDataRange().getValues();
    const headers = (data[0] || []).map(String);
    const userIdx = getColIndex(headers, 'userId');
    const sessIdx = getColIndex(headers, 'sessionId');

    for (let i = data.length - 1; i >= 1; i--) {
      if (String(data[i][userIdx]).trim() === String(userId).trim() &&
          String(data[i][sessIdx]).trim() === String(sessionId).trim()) {
        sheet.deleteRow(i + 1);
        break;
      }
    }
    return { success: true };
  } catch(e) {
    return { success: true }; // always succeed — don't block logout
  }
}

function checkSession(userId, sessionId) {
  try {
    ensureHeaders(SHEETS.sessions, HEADERS.sessions);
    const sheet   = getSheet(SHEETS.sessions);
    const data    = sheet.getDataRange().getValues();
    if (data.length < 2) return { valid: true }; // no sessions recorded — allow

    const headers = data[0].map(String);
    const userIdx = getColIndex(headers, 'userId');
    const sessIdx = getColIndex(headers, 'sessionId');

    for (let i = 1; i < data.length; i++) {
      if (String(data[i][userIdx]).trim() !== String(userId).trim()) continue;
      // Found user — check if session ID matches the registered one
      if (String(data[i][sessIdx]).trim() === String(sessionId).trim()) {
        return { valid: true };
      } else {
        return { valid: false, message: 'Session replaced on another device.' };
      }
    }

    // User not in sessions table (e.g. admin hardcoded / viewer) — allow
    return { valid: true };
  } catch(e) {
    return { valid: true }; // on any error, don't kick out
  }
}

// ─── SALES EXPORT ───────────────────────────
function getSalesExport(params) {
  ensureHeaders(SHEETS.salesExport, HEADERS.salesExport);
  const sheet   = getSheet(SHEETS.salesExport);
  const data    = sheet.getDataRange().getValues();
  if (data.length < 2) return { success: true, data: [] };

  const headers = data[0].map(String);
  const rows = data.slice(1)
    .map(row => {
      const obj = {};
      headers.forEach((h, i) => {
        const v = row[i];
        obj[h] = (v instanceof Date)
          ? Utilities.formatDate(v, Session.getScriptTimeZone(), "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
          : (v !== null && v !== undefined ? String(v) : '');
      });
      return obj;
    })
    .filter(obj => obj.id && obj.id.trim() !== '');

  // Optional date filter from params
  const from = params && params.from ? new Date(params.from) : null;
  const to   = params && params.to   ? new Date(params.to)   : null;
  const filtered = (from || to)
    ? rows.filter(r => {
        if (!r.transactionDate) return false;
        const d = new Date(r.transactionDate);
        if (from && d < from) return false;
        if (to   && d > to)   return false;
        return true;
      })
    : rows;

  return { success: true, data: filtered };
}

function saveSalesExportRows(payload) {
  ensureHeaders(SHEETS.salesExport, HEADERS.salesExport);
  const sheet = getSheet(SHEETS.salesExport);
  let rows = [];
  try { rows = JSON.parse(payload.rows || '[]'); } catch(e) { return { success: false, message: 'Invalid rows JSON.' }; }
  if (!rows.length) return { success: true, count: 0 };

  const data = rows.map(r => [
    generateId(),
    r.transactionId   || '',
    r.transactionDate || '',
    r.transactionTime || '',
    r.cashier         || '',
    r.paymentMethod   || 'Cash Sale',
    r.barcode         || '',
    r.stockNo         || '',
    r.productName     || '',
    parseInt(r.quantity   || 0) || 0,
    r.uomCode         || 'PC',
    r.discount1       || '',
    r.discount2       || '',
    r.discount3       || '',
    r.discount4       || '',
    parseFloat(r.price  || 0) || 0,
    parseFloat(r.amount || 0) || 0,
    r.remarks         || '',
  ]);

  const startRow = Math.max(sheet.getLastRow(), 1) + 1;
  sheet.getRange(startRow, 1, data.length, data[0].length).setValues(data);

  // Force date/time columns as text
  const dateCol = HEADERS.salesExport.indexOf('transactionDate') + 1;
  const timeCol = HEADERS.salesExport.indexOf('transactionTime') + 1;
  if (dateCol > 0) sheet.getRange(startRow, dateCol, data.length, 1).setNumberFormat('@');
  if (timeCol > 0) sheet.getRange(startRow, timeCol, data.length, 1).setNumberFormat('@');

  return { success: true, count: data.length };
}

// ─── SETUP (run once manually) ───────────────
function setupSheets() {
  Object.entries(HEADERS).forEach(([key, headers]) => {
    ensureHeaders(SHEETS[key], headers);
    Logger.log('Initialized: ' + SHEETS[key]);
  });
  Logger.log('All sheets ready!');
}
